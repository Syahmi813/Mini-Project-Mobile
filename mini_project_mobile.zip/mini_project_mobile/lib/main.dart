// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[50],
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),
      home: const LoginScreen(),
    );
  }
}

// =========================================================================
// 1. LOGIN SCREEN
// =========================================================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _dbHelper = DBHelper();

  void _login() async {
    String email = _emailController.text.trim();
    String password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    var user = await _dbHelper.loginUser(email, password);

    if (user != null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => DashboardScreen(userData: user),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid email or password.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Restaurant Login'), automaticallyImplyLeading: false),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🍴', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 24),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
              obscureText: true,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _login,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
              child: const Text('Login', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}

// =========================================================================
// 2. CUSTOMER DASHBOARD SCREEN
// =========================================================================
class DashboardScreen extends StatefulWidget {
  final Map<String, dynamic> userData;
  const DashboardScreen({super.key, required this.userData});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final DBHelper _dbHelper = DBHelper();
  late Future<List<Map<String, dynamic>>> _packagesFuture;

  @override
  void initState() {
    super.initState();
    _packagesFuture = _dbHelper.getAllPackages();
  }

  void _openBookingSheet(Map<String, dynamic> package) {
    final guestsController = TextEditingController(text: '10');
    final dateController = TextEditingController(text: '2026-06-15');
    final timeController = TextEditingController(text: '19:00');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            top: 20,
            left: 20,
            right: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Book ${package['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text('\$${package['pricePerGuest']} per guest base rate', style: TextStyle(color: Colors.grey[600])),
              const Divider(height: 24),
              TextField(
                controller: guestsController,
                decoration: const InputDecoration(labelText: 'Number of Guests', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: dateController,
                decoration: const InputDecoration(labelText: 'Event Date (YYYY-MM-DD)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: timeController,
                decoration: const InputDecoration(labelText: 'Event Time', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  int guests = int.tryParse(guestsController.text) ?? 10;
                  double baseRate = (package['pricePerGuest'] as num).toDouble();
                  double grandTotal = guests * baseRate;

                  Navigator.pop(context);

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PaymentScreen(
                        userId: widget.userData['id'],
                        package: package,
                        guests: guests,
                        date: dateController.text,
                        time: timeController.text,
                        totalPrice: grandTotal,
                      ),
                    ),
                  );
                },
                child: const Text('Proceed to Payment'),
              )
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome, ${widget.userData['name']}'),
        actions: [
          TextButton.icon(
            style: TextButton.styleFrom(foregroundColor: Colors.white),
            icon: const Text('📋', style: TextStyle(fontSize: 16)),
            label: const Text('My Bookings'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BookingHistoryScreen(userId: widget.userData['id']),
                ),
              );
            },
          ),
          IconButton(
            icon: const Text('🚪', style: TextStyle(fontSize: 16)),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Available Catering Packages',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text('Tap a package option card to start booking', style: TextStyle(color: Colors.grey[600])),
            const SizedBox(height: 12),
            Expanded(
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: _packagesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error loading data: ${snapshot.error}'));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(child: Text('No packages found.'));
                  }

                  final packages = snapshot.data!;

                  return ListView.builder(
                    itemCount: packages.length,
                    itemBuilder: (context, index) {
                      final package = packages[index];
                      return Card(
                        elevation: 4,
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        child: InkWell(
                          onTap: () => _openBookingSheet(package),
                          borderRadius: BorderRadius.circular(4),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        package['name'],
                                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(package['description'], style: TextStyle(color: Colors.grey[700], height: 1.3)),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  '\$${package['pricePerGuest']}/gst',
                                  style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 15),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =========================================================================
// 3. PAYMENT CHECKOUT SCREEN
// =========================================================================
class PaymentScreen extends StatefulWidget {
  final String userId;
  final Map<String, dynamic> package;
  final int guests;
  final String date;
  final String time;
  final double totalPrice;

  const PaymentScreen({
    super.key,
    required this.userId,
    required this.package,
    required this.guests,
    required this.date,
    required this.time,
    required this.totalPrice,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _cardNumberController = TextEditingController(text: "4111 2222 3333 4444");
  final _expiryController = TextEditingController(text: "12/29");
  final _cvvController = TextEditingController(text: "123");
  bool _isProcessing = false;

  void _processPayment() async {
    setState(() { _isProcessing = true; });

    await Future.delayed(const Duration(seconds: 2));

    String reservationId = 'res_${DateTime.now().millisecondsSinceEpoch}';

    final bookingData = {
      'id': reservationId,
      'userId': widget.userId,
      'packageId': widget.package['id'],
      'packageName': widget.package['name'],
      'eventDate': widget.date,
      'eventTime': widget.time,
      'numGuests': widget.guests,
      'customizationPrice': 0.0,
      'totalPrice': widget.totalPrice,
    };

    int result = await DBHelper().createReservation(bookingData);

    if (mounted) {
      setState(() { _isProcessing = false; });
      if (result != -1) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ReceiptScreen(receiptData: bookingData),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Checkout Payment'),
        leading: IconButton(
          icon: const Text('◀', style: TextStyle(fontSize: 16, color: Colors.white)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Amount Due: \$${widget.totalPrice.toStringAsFixed(2)}',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.green)),
            const SizedBox(height: 8),
            Text('Paying for: ${widget.package['name']}', style: TextStyle(color: Colors.grey[700])),
            const Divider(height: 32),
            const Text('Credit Card Details', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: _cardNumberController,
              decoration: const InputDecoration(
                  labelText: 'Card Number',
                  border: OutlineInputBorder(),
                  prefixIcon: Padding(
                    padding: EdgeInsets.symmetric(vertical: 14.0, horizontal: 12.0),
                    child: Text('💳', style: TextStyle(fontSize: 18)),
                  )
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(16),
                CardNumberInputFormatter(),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _expiryController,
                    decoration: const InputDecoration(labelText: 'Expiry Date', border: OutlineInputBorder(), hintText: 'MM/YY'),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _cvvController,
                    decoration: const InputDecoration(labelText: 'CVV', border: OutlineInputBorder()),
                    keyboardType: TextInputType.number,
                    obscureText: true,
                  ),
                ),
              ],
            ),
            const Spacer(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(55),
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              onPressed: _isProcessing ? null : _processPayment,
              child: _isProcessing
                  ? const CircularProgressIndicator(color: Colors.white)
                  : Text('Pay \$${widget.totalPrice.toStringAsFixed(2)} Now', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}

class CardNumberInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    var text = newValue.text;
    if (newValue.selection.baseOffset == 0) return newValue;
    var buffer = StringBuffer();
    for (int i = 0; i < text.length; i++) {
      buffer.write(text[i]);
      var nonZeroIndex = i + 1;
      if (nonZeroIndex % 4 == 0 && nonZeroIndex != text.length) {
        buffer.write(' ');
      }
    }
    var string = buffer.toString();
    return newValue.copyWith(
      text: string,
      selection: TextSelection.collapsed(offset: string.length),
    );
  }
}

// =========================================================================
// 4. DIGITAL RECEIPT SCREEN
// =========================================================================
class ReceiptScreen extends StatelessWidget {
  final Map<String, dynamic> receiptData;
  const ReceiptScreen({super.key, required this.receiptData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text('Transaction Receipt'),
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Card(
            elevation: 6,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('✅', style: TextStyle(fontSize: 50)),
                  const SizedBox(height: 12),
                  const Text('Payment Successful!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.green)),
                  Text('Thank you for your catering booking order.', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                  const Divider(height: 32, thickness: 1.2),

                  _buildReceiptRow('Receipt ID:', receiptData['id'].toString().substring(0, 14)),
                  _buildReceiptRow('Package Ordered:', receiptData['packageName']),
                  _buildReceiptRow('Target Date:', receiptData['eventDate']),
                  _buildReceiptRow('Target Time:', receiptData['eventTime']),
                  _buildReceiptRow('Total Attendance:', '${receiptData['numGuests']} pax'),

                  const Divider(height: 32, thickness: 1.2),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total Paid', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Text('\$${(receiptData['totalPrice'] as num).toStringAsFixed(2)}',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green)),
                    ],
                  ),
                  const SizedBox(height: 32),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('Back to Home Dashboard'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildReceiptRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.black54)),
          Expanded(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }
}

// =========================================================================
// 5. BOOKING HISTORY SCREEN
// =========================================================================
class BookingHistoryScreen extends StatefulWidget {
  final String userId;
  const BookingHistoryScreen({super.key, required this.userId});

  @override
  State<BookingHistoryScreen> createState() => _BookingHistoryScreenState();
}

class _BookingHistoryScreenState extends State<BookingHistoryScreen> {
  final DBHelper _dbHelper = DBHelper();
  late Future<List<Map<String, dynamic>>> _reservationsFuture;

  @override
  void initState() {
    super.initState();
    _refreshReservations();
  }

  void _refreshReservations() {
    setState(() {
      _reservationsFuture = _dbHelper.getUserReservations(widget.userId);
    });
  }

  void _cancelBooking(String reservationId) async {
    int result = await _dbHelper.deleteReservation(reservationId);
    if (result > 0) {
      setState(() {
        _refreshReservations();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Reservation successfully cancelled.'), backgroundColor: Colors.redAccent),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Catering Bookings'),
        leading: IconButton(
          icon: const Text('◀', style: TextStyle(fontSize: 16, color: Colors.white)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _reservationsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error loading reservations: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('📅', style: TextStyle(fontSize: 48)),
                  SizedBox(height: 16),
                  Text('No active bookings found.', style: TextStyle(fontSize: 18, color: Colors.grey)),
                ],
              ),
            );
          }

          final reservations = snapshot.data!;

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: reservations.length,
            itemBuilder: (context, index) {
              final res = reservations[index];
              return Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              res['packageName'] ?? 'Catering Package',
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
                            ),
                          ),
                          Text(
                            '\$${(res['totalPrice'] as num).toStringAsFixed(2)}',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green),
                          ),
                        ],
                      ),
                      const Divider(height: 20),
                      Row(
                        children: [
                          Text('📅 Date: ${res['eventDate']}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                          const SizedBox(width: 20),
                          Text('⏰ Time: ${res['eventTime']}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('👥 Guests: ${res['numGuests']} pax', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                          TextButton(
                            style: TextButton.styleFrom(foregroundColor: Colors.red),
                            onPressed: () => _cancelBooking(res['id']),
                            child: const Text('❌ Cancel Booking', style: TextStyle(fontWeight: FontWeight.bold)),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// =========================================================================
// 6. DATABASE HELPER (ADDED 5 MENU SELECTIONS HERE)
// =========================================================================
class DBHelper {
  static const _databaseName = "restaurant.db";
  static const _databaseVersion = 1;
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = p.join(await getDatabasesPath(), _databaseName);
    return await openDatabase(path, version: _databaseVersion, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (id TEXT PRIMARY KEY, name TEXT, email TEXT UNIQUE, password TEXT, role TEXT)
    ''');
    await db.execute('''
      CREATE TABLE packages (id TEXT PRIMARY KEY, name TEXT, description TEXT, pricePerGuest REAL)
    ''');
    await db.execute('''
      CREATE TABLE reservations (id TEXT PRIMARY KEY, userId TEXT, packageId TEXT, packageName TEXT, eventDate TEXT, eventTime TEXT, numGuests INTEGER, customizationPrice REAL, totalPrice REAL)
    ''');

    // Menu 1
    await db.insert('packages', {
      'id': '1',
      'name': 'Gold Jubilee Package',
      'description': '5-Course Fine Dining, Premium Seafood Selection, and Custom Mocktails.',
      'pricePerGuest': 150.0
    });
    // Menu 2
    await db.insert('packages', {
      'id': '2',
      'name': 'Diamond Banquet Package',
      'description': '7-Course Luxury Caviar & Steak Tasting Menu, Custom Dessert Station.',
      'pricePerGuest': 250.0
    });
    // Menu 3 (New)
    await db.insert('packages', {
      'id': '3',
      'name': 'Asian Fusion Feast',
      'description': 'Dim Sum Platters, Wagyu Beef Noodles, Peking Duck, and Matcha Gelato.',
      'pricePerGuest': 120.0
    });
    // Menu 4 (New)
    await db.insert('packages', {
      'id': '4',
      'name': 'Mediterranean Gala',
      'description': 'Slow-roasted Lamb, Mezze Platters, Grilled Octopus, and Baklava Tower.',
      'pricePerGuest': 180.0
    });
    // Menu 5 (New)
    await db.insert('packages', {
      'id': '5',
      'name': 'Plant-Based Oasis',
      'description': 'Organic Harvest Salads, Truffle Mushroom Risotto, and Artisanal Vegan Tarts.',
      'pricePerGuest': 95.0
    });

    await db.insert('users', {
      'id': 'user_01',
      'name': 'Alex Smith',
      'email': 'test@restaurant.com',
      'password': 'password123',
      'role': 'client'
    });

    await db.insert('users', {
      'id': 'user_02',
      'name': 'Test User',
      'email': 'test@gmail.com',
      'password': 'password123',
      'role': 'client'
    });
  }

  Future<int> registerUser(Map<String, dynamic> userMap) async {
    final db = await database;
    try { return await db.insert('users', userMap); } catch (e) { return -1; }
  }

  Future<Map<String, dynamic>?> loginUser(String email, String password) async {
    final db = await database;
    List<Map<String, dynamic>> result = await db.query('users', where: 'email = ? AND password = ?', whereArgs: [email, password]);
    if (result.isNotEmpty) return result.first;
    return null;
  }

  Future<int> createReservation(Map<String, dynamic> reservationMap) async {
    final db = await database;
    try { return await db.insert('reservations', reservationMap); } catch (e) { return -1; }
  }

  Future<List<Map<String, dynamic>>> getAllPackages() async { final db = await database; return await db.query('packages'); }
  Future<List<Map<String, dynamic>>> getUserReservations(String userId) async { final db = await database; return await db.query('reservations', where: 'userId = ?', whereArgs: [userId]); }

  Future<int> deleteReservation(String id) async {
    final db = await database;
    return await db.delete('reservations', where: 'id = ?', whereArgs: [id]);
  }
}